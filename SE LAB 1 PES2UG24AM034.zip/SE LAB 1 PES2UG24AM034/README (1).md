# Airport Lost Baggage Recovery Portal

## Overview

The **Airport Lost Baggage Recovery Portal** is a requirements and system-design proposal for improving the recovery of lost or misrouted passenger baggage at airports.

The system cross-references **lost baggage claims** with **unrouted baggage scan logs** to identify potential matches and initiate appropriate recovery actions. If baggage cannot be matched within the defined time period, the system can escalate the case toward automated compensation.

## Repository Contents

The `docs/` folder contains the complete requirements package:

* **Baggage_Recovery_Requirements_Package.docx**

  * Functional Requirements (FR-001–FR-005)
  * Non-Functional Requirements (NFR-001–NFR-002)
  * UML Use-Case Diagram
  * Use-Case Flow Specification for the core use case

* **usecase_diagram.svg**

  * Standalone UML use-case diagram in SVG format

* **usecase_diagram.png**

  * Standalone UML use-case diagram in PNG format

## Key Features

* Cross-reference lost baggage claims with baggage scan logs
* Identify potential baggage matches
* Generate recovery alerts when a match is found
* Handle unmatched baggage cases
* Initiate automated compensation after the defined escalation period
* Support airport staff and passenger-facing recovery workflows

## Core Use Case

**UC-01: Cross-Reference Lost Baggage Claims Against Unrouted Scan Logs**

This use case forms the core of the proposed system. It compares reported lost baggage information against available baggage scan records to identify possible matches and trigger the appropriate recovery workflow.

## Requirements

The requirements package includes:

| Type           | Requirements       |
| -------------- | ------------------ |
| Functional     | FR-001 to FR-005   |
| Non-Functional | NFR-001 to NFR-002 |

Each requirement includes its ID, description, priority, acceptance criteria, and rationale.

## UML Use-Case Model

The UML diagram represents the system actors, use cases, and their relationships, including `«include»` and `«extend»` relationships.

## Documentation

For the complete requirements, acceptance criteria, UML diagram, and detailed use-case flow, refer to:

**`docs/Baggage_Recovery_Requirements_Package.docx`**

## Submission

This repository contains the complete documentation package required for the Airport Lost Baggage Recovery Portal requirements submission.
