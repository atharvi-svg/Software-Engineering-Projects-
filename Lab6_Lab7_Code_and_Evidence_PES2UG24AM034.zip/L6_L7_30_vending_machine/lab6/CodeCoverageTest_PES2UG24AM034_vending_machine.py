from vending_machine import make_change, purchase, select_item


def test_select_item_valid_and_invalid():
    assert select_item("water", {}, 200) == "invalid"
    assert select_item("cola", {"cola": 1}, 150) == "ok"


def test_select_item_stock_and_credit_checks():
    assert select_item("cola", {}, 150) == "sold_out"
    assert select_item("chips", {"chips": 1}, 99) == "insufficient"


def test_change_for_valid_credit_and_unrepresentable_remainder():
    assert make_change(185) == [100, 50, 25, 10]
    assert make_change(1) is None
    try:
        make_change(-1)
    except ValueError:
        pass
    else:
        raise AssertionError("negative amounts must fail")


def test_purchase_dispenses_and_returns_change():
    stock = {"cola": 2}
    assert purchase("cola", stock, 200) == ("dispensed", [50])
    assert stock["cola"] == 1


def test_purchase_rejects_invalid_stock_and_insufficient_credit():
    stock = {"cola": 0, "chips": 1}
    assert purchase("cola", stock, 200) == ("sold_out", [])
    assert purchase("chips", stock, 50) == ("insufficient", [])
    assert purchase("water", stock, 200) == ("invalid", [])


def test_purchase_reports_change_failure_without_deducting_stock(monkeypatch):
    import vending_machine as vm

    monkeypatch.setattr(vm, "make_change", lambda amount: None)
    stock = {"cola": 1}
    assert vm.purchase("cola", stock, 150) == ("no_exact_change", [])
    assert stock["cola"] == 1
