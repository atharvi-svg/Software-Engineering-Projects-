import vending_machine as vm


def test_select_item_decision_branches():
    assert vm.select_item("water", {}, 999) == "invalid"
    assert vm.select_item("cola", {"cola": 0}, 150) == "sold_out"
    assert vm.select_item("cola", {"cola": 1}, 149) == "insufficient"
    assert vm.select_item("cola", {"cola": 1}, 150) == "ok"


def test_make_change_guard_loop_and_remainder_branches():
    try:
        vm.make_change(-1)
    except ValueError as exc:
        assert str(exc) == "negative amount"
    else:
        raise AssertionError("negative values must be rejected")
    assert vm.make_change(0) == []
    assert vm.make_change(185) == [100, 50, 25, 10]
    assert vm.make_change(1) is None


def test_purchase_status_and_change_branches(monkeypatch):
    assert vm.purchase("bad", {}, 500) == ("invalid", [])
    stock = {"cola": 1}
    assert vm.purchase("cola", stock, 150) == ("dispensed", [])
    assert stock["cola"] == 0

    monkeypatch.setattr(vm, "make_change", lambda amount: None)
    stock = {"cola": 1}
    assert vm.purchase("cola", stock, 150) == ("no_exact_change", [])
    assert stock["cola"] == 1
