from hypothesis import given, strategies as st
from vending_machine import change_due, parse_coins, slot_position


@given(st.one_of(st.none(), st.text()))
def test_parse_coins_does_not_crash(value):
    parse_coins(value)


@given(st.one_of(st.none(), st.text()))
def test_slot_position_does_not_crash(value):
    slot_position(value)


@given(st.one_of(st.none(), st.text()))
def test_change_due_does_not_crash(value):
    change_due(value)
