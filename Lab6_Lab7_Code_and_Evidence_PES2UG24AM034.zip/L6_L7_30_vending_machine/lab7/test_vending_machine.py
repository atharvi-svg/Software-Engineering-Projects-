import re
import pytest
from hypothesis import given, strategies as st
from vending_machine import change_due, parse_coins, slot_position


def _handled(function, value):
    try:
        return function(value)
    except (TypeError, ValueError):
        return None


@given(st.one_of(st.text(), st.none()))
def test_parse_coins_handles_arbitrary_inputs(s):
    result = _handled(parse_coins, s)
    if result is not None:
        assert isinstance(result, list)
        assert all(isinstance(value, int) and value >= 0 for value in result)


@given(st.one_of(st.text(), st.none()))
def test_slot_position_handles_arbitrary_inputs(s):
    result = _handled(slot_position, s)
    if result is not None:
        row, column = result
        assert 0 <= row < 26
        assert column >= 0


@given(st.one_of(st.text(), st.none()))
def test_change_due_handles_arbitrary_inputs(s):
    result = _handled(change_due, s)
    if result is not None:
        assert re.fullmatch(r"\d+ five-coins", result)


@given(st.lists(st.integers(min_value=0, max_value=10000), max_size=20))
def test_parse_coins_round_trip(values):
    text = ",".join(map(str, values))
    assert parse_coins(text) == values


@given(st.sampled_from(list("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz")), st.integers(min_value=1, max_value=100000))
def test_slot_position_valid_codes(letter, column):
    assert slot_position(f"{letter}{column}") == (ord(letter.upper()) - ord("A"), column - 1)


@given(st.integers(min_value=1, max_value=100000), st.integers(min_value=0, max_value=100000))
def test_change_due_valid_payments(price, five_coin_count):
    paid = price + five_coin_count * 5
    assert change_due(f"{paid}/{price}") == f"{five_coin_count} five-coins"


@pytest.mark.parametrize("text", ["1,,3", "1,a", "-1", "1.5"])
def test_parse_coins_rejects_malformed_values(text):
    with pytest.raises(ValueError):
        parse_coins(text)


@pytest.mark.parametrize("code", ["", "A0", "A-1", "A1B", "[1"])
def test_slot_position_rejects_invalid_codes(code):
    with pytest.raises(ValueError):
        slot_position(code)


@pytest.mark.parametrize("payment", ["100", "100/", "x/50", "50/100", "101/100", "100/0", "1/2/3"])
def test_change_due_rejects_invalid_payments(payment):
    with pytest.raises(ValueError):
        change_due(payment)
