"""Input parsing helpers for the vending machine lab."""
import re


def parse_coins(coins_csv):
    """Parse a CSV string of non-negative integer coin amounts."""
    if not isinstance(coins_csv, str):
        raise TypeError("coins_csv must be a string")
    if not coins_csv.strip():
        return []
    tokens = coins_csv.split(",")
    coins = []
    for token in tokens:
        token = token.strip()
        if not token or not re.fullmatch(r"[0-9]+", token):
            raise ValueError("coin values must be non-negative integers")
        coins.append(int(token))
    return coins


def slot_position(code):
    """Convert a slot like B7 to zero-based (row, column) indices."""
    if not isinstance(code, str):
        raise TypeError("slot code must be a string")
    if not re.fullmatch(r"[A-Za-z][1-9][0-9]*", code):
        raise ValueError("slot code must be a letter A-Z followed by a positive number")
    return ord(code[0].upper()) - ord("A"), int(code[1:]) - 1


def change_due(payment):
    """Return change as five-coin count; reject malformed or unrepresentable input."""
    if not isinstance(payment, str):
        raise TypeError("payment must be a string")
    parts = payment.split("/")
    if len(parts) != 2 or not all(part.strip() for part in parts):
        raise ValueError("payment must have the form paid/price")
    try:
        paid, price = (int(part.strip()) for part in parts)
    except ValueError as exc:
        raise ValueError("paid and price must be integers") from exc
    if paid < 0 or price <= 0:
        raise ValueError("paid must be non-negative and price must be positive")
    if paid < price:
        raise ValueError("payment is less than price")
    change = paid - price
    if change % 5:
        raise ValueError("change must be divisible into five-unit coins")
    return f"{change // 5} five-coins"


def main():
    print("==== Running parse_coins ====")
    user_input = input("Enter coin values as CSV (e.g. 5,10,25): ")
    try:
        print("Coins:", parse_coins(user_input))
    except (TypeError, ValueError) as exc:
        print("Invalid coin input:", exc)

    print("\n==== Running slot_position ====")
    user_input = input("Enter a slot code (e.g. B7): ")
    try:
        print("Row and Column:", slot_position(user_input))
    except (TypeError, ValueError) as exc:
        print("Invalid slot code:", exc)

    print("\n==== Running change_due ====")
    user_input = input("Enter paid/price (e.g. 200/150): ")
    try:
        print("Change Due:", change_due(user_input))
    except (TypeError, ValueError) as exc:
        print("Invalid payment:", exc)


if __name__ == "__main__":
    main()
