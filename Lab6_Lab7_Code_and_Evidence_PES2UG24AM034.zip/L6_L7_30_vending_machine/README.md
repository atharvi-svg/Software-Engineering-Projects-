# PES2UG24AM034 - Lab 6 and Lab 7

Assigned repository: https://github.com/SETAPESU26/L6_L7_30_vending_machine

## Lab 6 - code and branch coverage

The application follows the assigned repository source. The two suites provide line-focused and branch-focused cases. From the repository root:

```powershell
python -m pip install pytest coverage
Set-Location lab6
python -m coverage run --source=vending_machine -m pytest CodeCoverageTest_PES2UG24AM034_vending_machine.py -q
python -m coverage report -m
python -m coverage erase
python -m coverage run --branch --source=vending_machine -m pytest BranchCoverageTest_PES2UG24AM034_vending_machine.py -q
python -m coverage report -m
```

## Lab 7 - Hypothesis fuzz testing

The assigned repository uses `vending_machine.py` and `test_vending_machine.py`; the handout's `processor.py` names do not match this repo. From the repository root:

```powershell
python -m pip install pytest hypothesis
Set-Location ..\lab7
python vending_machine.py
python -m pytest test_vending_machine.py -q
```

The original Lab 7 implementation and a failing fuzz test suite are in `lab7/baseline/` for before/after evidence. The fixed suite accepts valid values and raises clear `TypeError` or `ValueError` exceptions for malformed inputs.
