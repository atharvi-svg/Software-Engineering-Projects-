# Lab 3: Component Modelling & Architectural Pattern Selection
## Self-Service Coffee Kiosk System

### Overview
This lab evaluates architectural styles (Layered, Microservices, Client-Server), selects the most suitable one for a Self-Service Coffee Kiosk, and models it as a UML Component Diagram with provided and required interfaces.

### Scenario
A self-service kiosk in a busy café where customers:
- Select a coffee (Espresso, Americano, Latte)
- Choose a size (Small, Large)
- Pay by credit card only
- Receive a printed receipt

**Technical constraints:** touch-screen interaction, receipt printer hardware connection, and storage of menu and pricing data.

### Selected Architecture: Layered Architecture
| Layer | Component(s) |
|---|---|
| Presentation | User Interface Component |
| Business | Order Manager, Payment Service, Receipt Printer |
| Data | Database Component |

### Components (5)
1. **User Interface Component** – touch-screen for drink, size and payment prompts
2. **Order Manager Component** – order workflow, price total, coordinates all services
3. **Payment Service Component** – credit-card authorisation
4. **Receipt Printer Component** – formats and prints receipts
5. **Database Component** – menu items, sizes and pricing

### Interfaces (4)
| Interface | Provided by | Required by | Type |
|---|---|---|---|
| IOrderService | Order Manager | User Interface | API calls |
| IMenuData | Database | Order Manager | Database queries |
| IPayment | Payment Service | Order Manager | API call |
| IReceipt | Receipt Printer | Order Manager | Hardware interface |

### Data Flow
1. UI sends order request to Order Manager
2. Order Manager queries menu and prices from the Database
3. Order Manager sends payment request to Payment Service
4. Order Manager sends receipt data to Receipt Printer

### Why Layered?
- The kiosk is small, fixed-scope and runs on a single device
- Clear separation of concerns gives easily replaceable components
- Security: the UI cannot access payment or data directly, and card data stays isolated in the Payment Service
- Performance: in-process calls and local queries keep the kiosk fast

See `Lab3_Justification.pdf` for the full justification.

### Files
| File | Description |
|---|---|
| `Lab3_Component_Diagram.pdf` | UML component diagram (PDF) |
| `Lab3_Component_Diagram.png` | UML component diagram (PNG) |
| `Lab3_Justification.pdf` | One-page architecture justification |

### Tools
UML diagram drawn with ReportLab (Python); justification generated as PDF.

### Author
<Your Name> | <Roll No.> | <Course / Section>
